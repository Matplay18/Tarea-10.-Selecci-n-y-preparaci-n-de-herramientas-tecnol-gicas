import { useState } from 'react';
import axios from 'axios';

export default function LeadForm() {
  const [form, setForm] = useState({ nombre: '', correo: '', mensaje: '' });

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post(import.meta.env.VITE_API_URL, form);
    alert('¡Lead enviado con éxito!');
    setForm({ nombre: '', correo: '', mensaje: '' });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="nombre" value={form.nombre} onChange={handleChange} placeholder="Tu nombre" required />
      <input name="correo" value={form.correo} onChange={handleChange} placeholder="Tu correo" required />
      <textarea name="mensaje" value={form.mensaje} onChange={handleChange} placeholder="Mensaje" />
      <button type="submit">Enviar</button>
    </form>
  );
}
