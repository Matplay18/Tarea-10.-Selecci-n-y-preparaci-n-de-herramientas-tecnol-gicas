import LeadForm from './components/LeadForm';

function App() {
  return (
    <div>
      <h1>Captura de Leads</h1>
      <LeadForm />
    </div>
  );
}

export default App;
