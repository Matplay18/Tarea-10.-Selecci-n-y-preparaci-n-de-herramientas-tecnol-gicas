const express = require('express');
const router = express.Router();
const { registrarLead, obtenerLeads } = require('../controllers/leadController');

router.post('/', registrarLead);
router.get('/', obtenerLeads);

module.exports = router;
