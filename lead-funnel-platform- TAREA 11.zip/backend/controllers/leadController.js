const Lead = require('../models/Lead');
const sendEmail = require('../utils/sendEmail');

const registrarLead = async (req, res) => {
  try {
    const nuevoLead = new Lead(req.body);
    await nuevoLead.save();

    await sendEmail(nuevoLead.correo, 'Gracias por tu interés', 'Pronto te contactaremos.');
    res.status(201).json({ mensaje: 'Lead registrado con éxito' });
  } catch (error) {
    res.status(500).json({ error: 'Error al guardar el lead' });
  }
};

const obtenerLeads = async (req, res) => {
  const leads = await Lead.find();
  res.json(leads);
};

module.exports = { registrarLead, obtenerLeads };
