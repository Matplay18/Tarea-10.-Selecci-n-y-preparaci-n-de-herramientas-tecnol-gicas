# LeadFunnel Platform

Plataforma sencilla para registrar leads mediante un formulario web conectado a una API Node.js y base de datos MongoDB.

## 🚀 Cómo iniciar

### Backend
```bash
cd backend
npm install
npm run dev
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## 🔧 Variables de entorno
- `.env` en backend:
  - `MONGO_URI`
  - `EMAIL_USER`
  - `EMAIL_PASS`

- `.env` en frontend:
  - `VITE_API_URL=http://localhost:5000/api/leads`

## 🧱 Arquitectura
- React (frontend)
- Express + MongoDB (backend)
- Nodemailer para correos automáticos
