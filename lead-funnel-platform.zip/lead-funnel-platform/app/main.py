from fastapi import FastAPI
from app.routes import leads

# Inicializa FastAPI
app = FastAPI(
    title="Lead Funnel Platform",
    description="API para automatización de embudos de marketing digital",
    version="1.0"
)

# Agrega las rutas de leads
app.include_router(leads.router)
