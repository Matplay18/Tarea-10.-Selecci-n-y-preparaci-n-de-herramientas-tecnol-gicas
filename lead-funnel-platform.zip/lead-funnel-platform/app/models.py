from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime

class Lead(BaseModel):
    name: str
    email: EmailStr
    interest: Optional[str] = None
    created_at: datetime = datetime.utcnow()
