import os
from dotenv import load_dotenv

# Carga variables desde el archivo .env
load_dotenv()

# Variables accesibles desde otros módulos
MONGO_URI = os.getenv("MONGO_URI")
DATABASE_NAME = os.getenv("DATABASE_NAME")
