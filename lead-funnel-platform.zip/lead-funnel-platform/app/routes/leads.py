from fastapi import APIRouter, HTTPException
from app.models import Lead
from motor.motor_asyncio import AsyncIOMotorClient
from app.config import MONGO_URI, DATABASE_NAME

# Inicializa la ruta
router = APIRouter()

# Conecta a MongoDB
client = AsyncIOMotorClient(MONGO_URI)
db = client[DATABASE_NAME]
collection = db["leads"]

# Ruta POST para crear un nuevo lead
@router.post("/leads/")
async def create_lead(lead: Lead):
    result = await collection.insert_one(lead.dict())
    if result.inserted_id:
        return {"id": str(result.inserted_id), "message": "Lead creado exitosamente"}
    raise HTTPException(status_code=500, detail="Error al guardar lead")
